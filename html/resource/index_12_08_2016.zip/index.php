<?php

$mysqli = new mysqli('127.0.0.1', 'root', '', 'for_temp');
if ($mysqli->connect_error) {
    die('Ошибка подключения (' . $mysqli->connect_errno . ') ');
}

$users = 'Alex 1';

$result = $mysqli->query('SELECT login FROM users WHERE name="Alex 1"');

var_dump($result->num_rows);
while($data = $result->fetch_assoc()) {
    var_dump($data);
}